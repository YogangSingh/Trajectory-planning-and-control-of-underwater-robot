function params = sys_params()
m = 2.5; % kg
g = 9.81; % m/s/s
I = [0.00025,   0,          0;
     0,         0.000232,   0;
     0,   0,          0.0003738];
params.mass = m;
params.I    = I;
params.invI = inv(I);
params.gravity = g;
params.arm_length = 0.45; % m
params.minF = 0.0;
params.maxF = 3.0*m*g;
end
