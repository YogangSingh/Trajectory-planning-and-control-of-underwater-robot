function sdot = AUVEOM(t, s, controlhandle, trajhandle, params)
current_state = stateToQd(s);
desired_state = trajhandle(t, current_state);
[F, M] = controlhandle(t, current_state, desired_state, params);
sdot = AUVEOM_readonly(t, s, F, M, params);
end
